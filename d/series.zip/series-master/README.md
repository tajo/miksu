# Series Coding Challenge

For this challenge we're going to write a "series" function. The idea here is
that we want to call a _series_ of functions in order before calling a final
callback.

The basic api should look like this:

```js
series([...functions], callback);
```

```js
series([
  function one(callback) {
    callback(error, result);
  },
  function two(callback) {
    callback(error, result);
  }
], function(error, results) {
  error === error;
  // or
  results = [resultOne, resultTwo];
});
```

Each function in the series may be asynchronous so they are give a node-style
callback where the first argument passed is an error, and the second argument is
a result.

If one of the functions in the series calls the callback with an error we skip
the rest of the functions in the series and call the final callback.

```js
series([
  function one(callback) {
    callback(new Error('Oh no!'));
  },
  function two(callback) {
    // never called
  }
], function(error, results) {
  // error === new Error('Oh no!');
  // results === undefined
});
```

The final `results` array should include the values passed to the callbacks.

> Note: `results` should include `undefined` values even if nothing is passed.

```js
series([
  function one(callback) {
    callback(null, 1);
  },
  function two(callback) {
    callback(null, 2)
  }
], function(error, results) {
  // error === undefined
  // results === [1, 2]
});
```
