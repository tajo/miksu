const series = require('./');

describe('series()', () => {
  it('should call each function', done => {
    let count = 0;
    series([
      function(cb) { count++; cb(); },
      function(cb) { count++; cb(); },
      function(cb) { count++; cb(); }
    ], function() {
      expect(count).toBe(3);
      done();
    });
  });

  it('should call each function in order', done => {
    let calls = [];
    series([
      function(cb) { calls.push(1); cb(); },
      function(cb) { calls.push(2); cb(); },
      function(cb) { calls.push(3); cb(); }
    ], function() {
      expect(calls).toEqual([1, 2, 3]);
      done();
    });
  });

  it('should not call the second function before the first one is finished', done => {
    let called = false;
    series([
      function(cb) {
        setTimeout(function() {
          called = true;
          cb();
        }, 1);
      },
      function(cb) {
        expect(called).toBeTruthy();
        cb();
      }
    ], done);
  });

  it('should not call the final callback before finishing all the functions', done => {
    let count = 0;
    series([
      function(cb) { setTimeout(function() { count++; cb(); }, 1); },
      function(cb) { setTimeout(function() { count++; cb(); }, 1); },
      function(cb) { setTimeout(function() { count++; cb(); }, 1); }
    ], function() {
      expect(count).toBe(3);
      done();
    });
  });

  it('should pass an error to the final callback as the first argument', done => {
    const errorInstance = new Error('Oh no!');
    series([
      function(cb) { cb(errorInstance); }
    ], function(err) {
      expect(err).toBe(errorInstance);
      done();
    });
  });

  it('should stop calling the functions in the series after getting an error', done => {
    let called = false;
    series([
      function(cb) { cb(new Error('Oh no!')); },
      function(cb) { called = true; cb(); }
    ], function() {
      expect(called).toBeFalsy();
      done();
    });
  });

  it('should pass the results to the final callback as the second argument', done => {
    series([
      function(cb) { cb(null, 1); },
      function(cb) { cb(null, 2); },
      function(cb) { cb(null, 3); }
    ], function(err, results) {
      expect(results).toEqual([1, 2, 3]);
      done();
    });
  });

  it('should pass the results to the final callback including undefined', done => {
    series([
      function(cb) { cb(null, 1); },
      function(cb) { cb(null, undefined); },
      function(cb) { cb(null, 3); }
    ], function(err, results) {
      expect(results).toEqual([1, undefined, 3]);
      done();
    });
  });
});
